package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText firstNumber = findViewById(R.id.firstNumber);
        EditText secondNumber = findViewById(R.id.secondNumber);
        Button addButton = findViewById(R.id.addButton);
        Button minusBUtton = findViewById(R.id.minusButton);
        Button multiplyButton = findViewById(R.id.multiplyButton);
        Button divideButton = findViewById(R.id.divideButton);

        TextView result = findViewById(R.id.resultView);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    double i = Double.parseDouble(firstNumber.getText().toString());
                    double j = Double.parseDouble(secondNumber.getText().toString());
                    double sum = i+j;
                    result.setText(String.valueOf(sum));
                }
                catch(Exception e)
                {
                    result.setText(String.valueOf(e));
                }
            }
        });

        minusBUtton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                try{
                    double i = Double.parseDouble(firstNumber.getText().toString());
                    double j = Double.parseDouble(secondNumber.getText().toString());
                    double sum = i-j;
                    result.setText(String.valueOf(sum));
                }
                catch(Exception e)
                {
                    result.setText(String.valueOf(e));
                }
            }
        });

        multiplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                try{
                    double i = Double.parseDouble(firstNumber.getText().toString());
                    double j = Double.parseDouble(secondNumber.getText().toString());
                    double sum = i*j;
                    result.setText(String.valueOf(sum));
                }
                catch(Exception e)
                {
                    result.setText(String.valueOf(e));
                }
            }
        });

        divideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                try{
                    double sum = 0;
                    double i = Double.parseDouble(firstNumber.getText().toString());
                    double j = Double.parseDouble(secondNumber.getText().toString());
                    if(j == 0) {
                        result.setText("Cannot divide by zero");
                    }
                    else {
                        sum = i / j;
                        result.setText(String.valueOf(sum));
                    }
                }
                catch(Exception e)
                {
                    result.setText(String.valueOf(e));
                }
            }
        });
    }
}